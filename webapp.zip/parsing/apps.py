from django.apps import AppConfig


class ParsingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'parsing'
